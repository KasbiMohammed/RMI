/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import entities.Machine;
import entities.Salle;
import idao.IDao;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import service.MachineService;
import service.SalleService;


public class Test {
    public static void main(String[] args)  {
        try {
            IDao<Machine>dao=new MachineService();
            IDao<Salle>idao=new SalleService();
            dao.create(new Machine( "VkT", "jP",578));
            dao.create(new Machine( "RYVkT", "HlP", 65578));
            dao.create(new Machine( "RYjVT", "HPm", 65798));
            for(Machine m:dao.findAll()){
                System.out.println(m);}
            idao.create(new Salle( "code1"));
            idao.create(new Salle( "code2"));
            for(Salle s:idao.findAll()){
                System.out.println(s);}
        } catch (RemoteException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
        
}
