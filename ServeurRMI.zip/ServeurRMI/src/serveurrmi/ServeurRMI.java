
package serveurrmi;


public class ServeurRMI {

    
    
}
