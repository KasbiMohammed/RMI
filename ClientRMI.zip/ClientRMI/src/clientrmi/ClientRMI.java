/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientrmi;

import entities.Machine;
import entities.Salle;
import idao.IDao;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pc.Dell
 */
public class ClientRMI {

    
    public static void main(String[] args) {
        try {
            IDao<Machine> idao  = (IDao<Machine>) Naming.lookup("rmi://localhost:1099/idao");
             idao.create(new Machine( "RYVkT", "HlP", 678));
            idao.create(new Machine( "RYjVT", "HPm", 698));
            idao.create(new Machine( "RYVkT", "HlP", 678));
            idao.create(new Machine( "KHYUT", "HPm", 65798));
            idao.create(new Machine( "JUY", "HlP", 658));
            idao.create(new Machine( "VT", "HUm", 658));
            idao.create(new Machine( "RYVkT", "lP", 78));
            idao.create(new Machine( "RYjVT", "Hm", 65798));
            for(Machine m:idao.findAll()){
                System.out.println(m);}
              idao.create(new Salle( "Code1"));
            idao.create(new Salle( "Code2"));
            idao.create(new Salle( "Code3"));
            idao.create(new Salle( "Code4"));
            idao.create(new Salle( "Code5");
            idao.create(new Salle( "Code6"));
            idao.create(new Salle( "Code7"));
            idao.create(new Salle( "Code8"));
            for(Salle s:idao.findAll()){
                System.out.println(s);}
        } catch (NotBoundException ex) {
            Logger.getLogger(ClientRMI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(ClientRMI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (RemoteException ex) {
            Logger.getLogger(ClientRMI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
